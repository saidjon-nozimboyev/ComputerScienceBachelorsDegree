#!/bin/bash

echo "================================"
echo "System Report Tool"
echo "================================"

read -p "Enter your name: " name

system_info() {
    username=$(whoami)
    hostname=$(hostname)
    directory=$(pwd)
    date=$(date)

    echo "System Programming Lab 2 Report"
    echo "Name: $name"
    echo "Username: $username"
    echo "Hostname: $hostname"
    echo "Date: $date"
    echo "Current Directory: $directory"
}

echo
system_info | tee report.txt

echo
read -p "Enter a filename: " filename

if [ -f "$filename" ]; then
    echo "File exists."
else
    echo "File does not exist."
fi

echo
echo "Bash scripts:"

for file in *.sh; do
    echo "$file"
done

echo
echo "Number of Bash scripts:"
ls *.sh | wc -l
