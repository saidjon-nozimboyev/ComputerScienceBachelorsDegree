#include <stdio.h>
#include <pthread.h>

int inventory = 100;
pthread_mutex_t inventory_mutex = PTHREAD_MUTEX_INITIALIZER;

void *sell(void *arg) {
    (void)arg;

    for (int i = 0; i < 50; i++) {
        /* Read, check, and update inventory while holding the same lock. */
        pthread_mutex_lock(&inventory_mutex);
        if (inventory > 0) {
            inventory--;
        }
        pthread_mutex_unlock(&inventory_mutex);
    }

    return NULL;
}

int main(void) {
    pthread_t t1, t2;

    if (pthread_create(&t1, NULL, sell, NULL) != 0) {
        perror("pthread_create");
        return 1;
    }
    if (pthread_create(&t2, NULL, sell, NULL) != 0) {
        perror("pthread_create");
        pthread_join(t1, NULL);
        return 1;
    }

    if (pthread_join(t1, NULL) != 0 || pthread_join(t2, NULL) != 0) {
        perror("pthread_join");
        return 1;
    }

    printf("Remaining inventory: %d\n", inventory);
    pthread_mutex_destroy(&inventory_mutex);
    return 0;
}

