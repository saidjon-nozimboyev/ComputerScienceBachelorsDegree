#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define NUM_THREADS 3

int completed = 0;
pthread_mutex_t completed_mutex = PTHREAD_MUTEX_INITIALIZER;

void *worker(void *arg) {
    int id = *(int *)arg;

    for (int i = 0; i < 3; i++) {
        /* Independent work happens outside the critical section */
        printf("Worker %d processing task %d\n", id, i + 1);
        sleep(1);

        /* Only the shared counter update needs protection */
        pthread_mutex_lock(&completed_mutex);
        completed++;
        pthread_mutex_unlock(&completed_mutex);
    }

    return NULL;
}

int main(void) {
    pthread_t threads[NUM_THREADS];
    int ids[NUM_THREADS] = {1, 2, 3};

    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_create(&threads[i], NULL, worker, &ids[i]) != 0) {
            perror("pthread_create");
            return 1;
        }
    }

    for (int i = 0; i < NUM_THREADS; i++) {
        if (pthread_join(threads[i], NULL) != 0) {
            perror("pthread_join");
            return 1;
        }
    }

    printf("Completed tasks: %d\n", completed);
    pthread_mutex_destroy(&completed_mutex);
    return 0;
}

