#include <stdio.h>
#include <pthread.h>

int balance = 1000;
pthread_mutex_t account_mutex = PTHREAD_MUTEX_INITIALIZER;

void *withdraw(void *arg) {
    int amount = *(int *)arg;

    pthread_mutex_lock(&account_mutex);
    if (balance >= amount) {
        balance -= amount;
        printf("Withdrawn: %d, Balance: %d\n", amount, balance);
    } else {
        printf("Insufficient funds for %d\n", amount);
    }
    pthread_mutex_unlock(&account_mutex);

    return NULL;
}

int main(void) {
    pthread_t t1, t2;
    int a = 700, b = 600;

    if (pthread_create(&t1, NULL, withdraw, &a) != 0) {
        perror("pthread_create");
        return 1;
    }
    if (pthread_create(&t2, NULL, withdraw, &b) != 0) {
        perror("pthread_create");
        pthread_join(t1, NULL);
        return 1;
    }

    if (pthread_join(t1, NULL) != 0 || pthread_join(t2, NULL) != 0) {
        perror("pthread_join");
        return 1;
    }

    printf("Final balance: %d\n", balance);
    pthread_mutex_destroy(&account_mutex);
    return 0;
}

