#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

static pid_t wait_for_any_child(int *status) {
    pid_t result;
    do {
        result = wait(status);
    } while (result == -1 && errno == EINTR);
    return result;
}

static void print_status(pid_t pid, int status) {
    printf("Collected child PID %ld: ", (long)pid);
    if (WIFEXITED(status)) {
        printf("exit status %d\n", WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("terminated by signal %d\n", WTERMSIG(status));
    } else {
        puts("ended in an unexpected way.");
    }
}

int main(void) {
    int created = 0;
    int fork_failed = 0;

    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            fork_failed = 1;
            break;
        }

        if (pid == 0) {
            printf("Child %d PID=%ld started\n", i + 1, (long)getpid());
            fflush(stdout);
            sleep((unsigned int)(3 - i));
            printf("Child %d PID=%ld finishing with exit status %d\n",
                   i + 1, (long)getpid(), i + 1);
            fflush(stdout);
            _exit(i + 1);
        }

        created++;
    }

    for (int i = 0; i < created; i++) {
        int status = 0;
        pid_t finished = wait_for_any_child(&status);
        if (finished == -1) {
            perror("wait");
            return EXIT_FAILURE;
        }
        print_status(finished, status);
    }

    puts("All created children collected; parent exiting.");
    return fork_failed ? EXIT_FAILURE : EXIT_SUCCESS;
}

