#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void) {
    for (int i = 0; i < 2; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            return EXIT_FAILURE;
        }

        if (pid == 0) {
            printf("Child %d (PID %ld) started\n", i + 1, (long)getpid());
            fflush(stdout);

            sleep(i == 0 ? 3 : 1);

            printf("Child %d (PID %ld) finishing with exit status %d\n",
                   i + 1, (long)getpid(), i + 1);
            fflush(stdout);
            _exit(i + 1);
        }
    }

    int status = 0;
    pid_t finished = wait(&status);  /* Intentionally wait for only one child. */

    if (finished == -1) {
        perror("wait");
        return EXIT_FAILURE;
    }

    printf("First collected child PID: %ld\n", (long)finished);
    if (WIFEXITED(status)) {
        printf("Exit status: %d\n", WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("Child terminated by signal: %d\n", WTERMSIG(status));
    } else {
        puts("Child terminated in an unexpected way.");
    }

    /* The other child is deliberately not waited for in this exercise. */
    return EXIT_SUCCESS;
}
