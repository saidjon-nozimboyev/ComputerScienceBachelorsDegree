#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

static pid_t wait_for_process(pid_t process_id, int *status) {
    pid_t result;
    do {
        result = waitpid(process_id, status, 0);
    } while (result == -1 && errno == EINTR);
    return result;
}

static void print_status(const char *label, pid_t pid, int status) {
    printf("%s PID %ld: ", label, (long)pid);
    if (WIFEXITED(status)) {
        printf("exit status %d\n", WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("terminated by signal %d\n", WTERMSIG(status));
    } else {
        puts("ended in an unexpected way.");
    }
    fflush(stdout);
}

int main(void) {
    printf("Parent PID=%ld\n", (long)getpid());
    fflush(stdout);

    pid_t child = fork();
    if (child < 0) {
        perror("fork (child)");
        return EXIT_FAILURE;
    }

    if (child == 0) {
        printf("Child PID=%ld PPID=%ld\n",
               (long)getpid(), (long)getppid());
        fflush(stdout);

        pid_t grandchild = fork();
        if (grandchild < 0) {
            perror("fork (grandchild)");
            _exit(1);
        }

        if (grandchild == 0) {
            printf("Grandchild PID=%ld PPID=%ld\n",
                   (long)getpid(), (long)getppid());
            fflush(stdout);
            sleep(2);
            puts("Grandchild finished.");
            fflush(stdout);
            _exit(0);
        }

        int grandchild_status = 0;
        pid_t reaped_grandchild = wait_for_process(grandchild, &grandchild_status);
        if (reaped_grandchild == -1) {
            perror("waitpid (grandchild)");
            _exit(1);
        }
        print_status("Child collected grandchild", reaped_grandchild,
                     grandchild_status);
        _exit(WIFEXITED(grandchild_status) &&
              WEXITSTATUS(grandchild_status) == 0 ? 0 : 1);
    }

    int child_status = 0;
    pid_t reaped_child = wait_for_process(child, &child_status);
    if (reaped_child == -1) {
        perror("waitpid (child)");
        return EXIT_FAILURE;
    }

    print_status("Parent collected child", reaped_child, child_status);
    puts("Parent done; both descendants have finished.");
    return (WIFEXITED(child_status) && WEXITSTATUS(child_status) == 0)
               ? EXIT_SUCCESS
               : EXIT_FAILURE;
}
