#define _POSIX_C_SOURCE 200809L
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

static pid_t wait_for_specific_child(pid_t child_pid, int *status) {
    pid_t result;
    do {
        result = waitpid(child_pid, status, 0);
    } while (result == -1 && errno == EINTR);
    return result;
}

static pid_t wait_for_any_child(int *status) {
    pid_t result;
    do {
        result = wait(status);
    } while (result == -1 && errno == EINTR);
    return result;
}

static void print_status(const char *label, pid_t pid, int status) {
    printf("%s PID %ld: ", label, (long)pid);
    if (WIFEXITED(status)) {
        printf("exit status %d\n", WEXITSTATUS(status));
    } else if (WIFSIGNALED(status)) {
        printf("terminated by signal %d\n", WTERMSIG(status));
    } else {
        puts("ended in an unexpected way.");
    }
}

int main(void) {
    pid_t children[3];
    int created = 0;

    for (int i = 0; i < 3; i++) {
        pid_t pid = fork();

        if (pid < 0) {
            perror("fork");
            /* Reap children already created before reporting failure. */
            for (int j = 0; j < created; j++) {
                int cleanup_status = 0;
                pid_t result = wait_for_specific_child(children[j], &cleanup_status);
                if (result == -1) {
                    perror("waitpid during cleanup");
                }
            }
            return EXIT_FAILURE;
        }

        if (pid == 0) {
            printf("Child %d PID=%ld started\n", i + 1, (long)getpid());
            fflush(stdout);
            sleep((unsigned int)(3 - i));
            printf("Child %d PID=%ld finishing with exit status %d\n",
                   i + 1, (long)getpid(), i + 1);
            fflush(stdout);
            _exit(i + 1);
        }

        children[i] = pid;
        created++;
    }

    int status = 0;
    pid_t finished = wait_for_specific_child(children[1], &status);
    if (finished == -1) {
        perror("waitpid (second-created child)");
        /* Fall back to reaping whichever children remain. */
        for (int i = 0; i < 3; i++) {
            int fallback_status = 0;
            pid_t result = wait_for_any_child(&fallback_status);
            if (result == -1) {
                if (errno != ECHILD) {
                    perror("wait during fallback");
                }
                break;
            }
            print_status("Fallback collected child", result, fallback_status);
        }
        return EXIT_FAILURE;
    }
    print_status("waitpid collected second-created child", finished, status);

    /* The two remaining children are collected in termination order. */
    for (int i = 0; i < 2; i++) {
        status = 0;
        finished = wait_for_any_child(&status);
        if (finished == -1) {
            perror("wait (remaining child)");
            return EXIT_FAILURE;
        }
        print_status("wait collected remaining child", finished, status);
    }

    puts("Parent done; all three children have been collected.");
    return EXIT_SUCCESS;
}
